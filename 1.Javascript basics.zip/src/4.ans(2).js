//object constructor ()
var person = new Object();
    
person.firstName = "Harry";
person["lastName"] = "Potter"; 
person.age = 13;
person.getFullName = function () {
        return this.firstName + ' ' + this.lastName;
    };