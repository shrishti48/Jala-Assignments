//2 methods
//Object literal method to construct object
var person = { 
  firstName: "Harry", 
  lastName: "Potter", 
  age: 13, 
  getFullName: function () { 
          return this.firstName + ' ' + this.lastName 
  }
}; 
