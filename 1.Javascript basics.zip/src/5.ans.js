//variable hoistind
x = 5; 

elem = document.getElementById("demo"); 
elem.innerHTML = x;                     
// variable declaration
var x