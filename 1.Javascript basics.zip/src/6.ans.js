"use strict";
myFunction();

function myFunction() {
  y = 3.14;  
  // This will cause an error because y is not declared
}